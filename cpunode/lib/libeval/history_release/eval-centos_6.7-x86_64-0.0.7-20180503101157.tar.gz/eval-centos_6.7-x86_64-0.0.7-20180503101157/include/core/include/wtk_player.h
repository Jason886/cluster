#ifndef WTK_AUDIO_WTK_PLAYER_H_
#define WTK_AUDIO_WTK_PLAYER_H_
#include "wtk/core/wtk_type.h"
#include <unistd.h>
#include <alsa/asoundlib.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_player wtk_player_t;
struct wtk_player
{
	snd_pcm_t *handler;
};

/**
 * @param buff_time ms.
 */
wtk_player_t* wtk_player_new(int sample_rate,int buff_time);
int wtk_player_delete(wtk_player_t *player);
int wtk_player_init(wtk_player_t* r,int sample_rate,int buff_time);
int wtk_player_clean(wtk_player_t* r);
int wtk_player_start(wtk_player_t *r);
int wtk_player_stop(wtk_player_t *r);
int wtk_player_write(wtk_player_t *p,char *data,int bytes);
#ifdef __cplusplus
};
#endif
#endif
