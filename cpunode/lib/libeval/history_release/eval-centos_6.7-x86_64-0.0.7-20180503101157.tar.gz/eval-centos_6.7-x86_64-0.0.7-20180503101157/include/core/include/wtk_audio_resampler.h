#ifndef WTK_AUDIO_WTK_AUDIO_RESAMPLER_H_
#define WTK_AUDIO_WTK_AUDIO_RESAMPLER_H_
#include "wtk/audio/wtk_decode.h"
#include "wtk/core/wtk_strbuf.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_audio_resampler wtk_audio_resampler_t;
typedef int (*wtk_audio_resampler_write_handler_t)(void *hook,char *buf,int buf_size);

struct wtk_audio_resampler
{
	void *ctx;
	int output_size;
	char *output_alloc;
	short *output;
	void *hook;
	wtk_audio_resampler_write_handler_t write;
	int dst_channel;
	int dst_samplerate;
	int dst_samplesize;

	int src_channel;
	int src_samplerate;
	int src_samplesize;

	int input_size;  //input buffer hint
	unsigned need_resample:1;
};

wtk_audio_resampler_t* wtk_audio_resampler_new(int dst_samplerate,void *hook,wtk_audio_resampler_write_handler_t write);
int wtk_audio_resampler_delete(wtk_audio_resampler_t *r);
int wtk_audio_resampler_start(wtk_audio_resampler_t *r,int channel,int samplerate,int samplesize);
int wtk_audio_resampler_stop(wtk_audio_resampler_t *r);
int wtk_audio_resampler_feed(wtk_audio_resampler_t *r,char *buf,int bytes);
int wtk_audio_resampler_run2(wtk_audio_resampler_t *r,int is_last,short *data,int len,int *pconsumed,wtk_strbuf_t *buf);
int wtk_audio_resampler_run3(wtk_audio_resampler_t *r,int is_last,short *data,int len,int *pconsumed,wtk_strbuf_t *buf);
#ifdef __cplusplus
};
#endif
#endif
