#ifndef WTK_AUDIO_WTK_ULAW_H_
#define WTK_AUDIO_WTK_ULAW_H_
#include "wtk/core/wtk_strbuf.h"
#include "g711.h"
#ifdef __cplusplus
extern "C" {
#endif
void wtk_alaw_to_lin(const char *a,int bytes,wtk_strbuf_t *buf);
void wtk_lin_to_alaw(const short *a,int len,wtk_strbuf_t *buf);
void wtk_lin_to_mulaw(const short *a,int len,wtk_strbuf_t *buf);
#ifdef __cplusplus
};
#endif
#endif
