#ifndef WTK_VITE_MATH_WTK_MAT_H_
#define WTK_VITE_MATH_WTK_MAT_H_
#include "wtk_type.h"
#include "wtk_matrix.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
	signed char *p;
	unsigned int row;
	unsigned int col;
	unsigned int p_row;
	unsigned int p_col;
	unsigned int p_row_x;
	unsigned int p_col_x;
}wtk_matc_t;

#define wtk_mat_at(a,i,j) ((a)->p+i*(a)->col+j)

wtk_matc_t* wtk_matc_new(int row,int col);
wtk_matc_t* wtk_matc_new2(wtk_matrix_t *m,float scale);
void wtk_matc_delete(wtk_matc_t *m);
void wtk_matc_print(wtk_matc_t *mc);
/**
 * |---------- row -------------|
 *   |
 *  col
 *   |
 * |----------------------------|
 */
wtk_matc_t* wtk_matc_new3(wtk_matrix_t *m,float scale);

typedef struct
{
	unsigned char *p;
	unsigned int row;
	unsigned int col;
	unsigned int p_row;
	unsigned int p_col;
	unsigned int p_row_x;
	unsigned int p_col_x;
}wtk_matuc_t;


wtk_matuc_t* wtk_matuc_new(int row,int col);
wtk_matuc_t* wtk_matuc_new2(wtk_matrix_t *m,float scale);
void wtk_matuc_init(wtk_matuc_t* cm,wtk_matrix_t *m,float scale);
void wtk_matuc_delete(wtk_matuc_t *mc);
void wtk_matuc_print(wtk_matuc_t *mc);

typedef struct
{
	int *p;
	unsigned int row;
	unsigned int col;
	unsigned int p_row;
	unsigned int p_col;
	unsigned int p_row_x;
	unsigned int p_col_x;
}wtk_mati_t;



wtk_mati_t* wtk_mati_new(int row,int col);
wtk_mati_t* wtk_mati_new2(wtk_matrix_t *m,float scale);
void wtk_mati_init(wtk_mati_t *im,wtk_matrix_t *m,float scale);
void wtk_mati_delete(wtk_mati_t *im);
void wtk_mati_print(wtk_mati_t *mi);

/*
 * m=|a*b|
 */
void wtk_mati_multi(wtk_mati_t *m,wtk_matuc_t *a,wtk_matc_t *b);
void wtk_mati_multi2(wtk_mati_t *m,wtk_mati_t *a,wtk_matc_t *b);
void wtk_mati_multi3(wtk_mati_t *m,wtk_mati_t *a,wtk_mati_t *b);
void wtk_mati_multi_dc(wtk_mati_t *m,wtk_mati_t *a,wtk_matc_t *b,int nx);
void wtk_mati_add(wtk_mati_t *a,wtk_mati_t *b);
void wtk_mati_multi4(wtk_mati_t *m,wtk_matc_t *a,wtk_matc_t *b);
void wtk_mati_multi4_2(wtk_mati_t *m,wtk_matc_t *a,wtk_matc_t *b);

void wtk_int_matrix_multi(wtk_int_matrix_t *m,wtk_matc_t *a,wtk_matc_t *b);
void wtk_mati_multi_x(wtk_mati_t *m,wtk_matc_t *a,wtk_matc_t *b);

void wtk_mati_multi_x_raw(wtk_mati_t *m,wtk_matuc_t *a,wtk_matc_t *b);

typedef wtk_mati_t* (*wtk_mati_heap_new_f)(void *ths,int row,int col);
typedef void (*wtk_mati_heap_delete_f)(void *ths,wtk_mati_t *m);

typedef struct
{
	void *ths;
	wtk_mati_heap_new_f mat_new;
	wtk_mati_heap_delete_f mat_delete;
}wtk_mati_heap_t;

void wtk_mati_multi_dc_ext(wtk_mati_t *c,wtk_mati_t *a,wtk_matc_t *b,
		wtk_mati_heap_t *heap,int NX);
void wtk_mati_multi_dc2(wtk_mati_t *c,wtk_mati_t *a,wtk_mati_t *b,wtk_mati_heap_t *heap,int NX);
void wtk_mati_multi_dc_ext_cc(wtk_mati_t *c,wtk_matc_t *a,wtk_matc_t *b,
		wtk_mati_heap_t *heap,int NX);
void wtk_mati_multi_dc_cc(wtk_mati_t *c,wtk_matc_t *a,wtk_matc_t *b,int nx);
typedef struct
{
	float *p;
	unsigned int row;
	unsigned int col;
}wtk_matf_t;

wtk_matf_t* wtk_matf_new(int row,int col);
wtk_matf_t* wtk_matf_new2(wtk_matrix_t *m);
void wtk_matf_print(wtk_matf_t *f);
void wtk_matf_mul_raw(wtk_matf_t *m,wtk_matf_t *a,wtk_matf_t *b);
void wtk_mati_multi_x_raw(wtk_mati_t *m,wtk_matuc_t *a,wtk_matc_t *b);
#ifdef __cplusplus
};
#endif
#endif
