#ifndef WTK_AUDIO_SPEEX_WTK_SPX_DEC_H_
#define WTK_AUDIO_SPEEX_WTK_SPX_DEC_H_
#include "wtk/core/wtk_type.h"
#include "wtk/core/wtk_strbuf.h"
#include <speex/speex.h>
#include <speex/speex_header.h>
#include <speex/speex_stereo.h>
#include <speex/speex_callbacks.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_spx_dec wtk_spx_dec_t;
/**
 * simple wrapper speex decoder;
 *
 *	wtk_spx_dec_t* dec;
 *
 *	dec=wtk_spx_dec_new();
 *	wtk_spx_dec_start(dec, ...)
 *	wtk_spx_dec_feed(dec,...)
 *	wtk_spx_dec_stop(dec,...)
 *	wtk_spx_dec_delete(dec);
 */

/**
 *	@brief write data, returned value is not check current;
 */
typedef int (*wtk_spx_dec_write_f)(void *hook,char *buf,int size);

struct wtk_spx_dec
{
	SpeexBits bits;
	void *st;
    int extra;
    int extralen;
    short * extradata;
	int frame_size;
	int channels;
    int rate;
	unsigned enh_enabled:1;
	wtk_spx_dec_write_f write_f;
	void* write_hook;
};

/**
 *	@brief create new decoder;
 */
wtk_spx_dec_t* wtk_spx_dec_new();

/**
 * @brief delete decoder;
 */
int wtk_spx_dec_delete(wtk_spx_dec_t *d);

/**
 * @brief initialize environment for feed, and data is packed to write;
 */
void wtk_spx_dec_start(wtk_spx_dec_t *d,wtk_spx_dec_write_f write,void *hook);

/**
 * @brief feed audio and decoded wav is saved to write hook;
 * @return 0 on success;
 */
int wtk_spx_dec_feed(wtk_spx_dec_t *d,char *data,int len);

/**
 * @brief clean decoder;
 */
void wtk_spx_dec_stop(wtk_spx_dec_t *d);
#ifdef __cplusplus
};
#endif
#endif
