#ifndef WTK_AUDIO_WTK_STERFILE_H_
#define WTK_AUDIO_WTK_STERFILE_H_
#include "wtk/audio/wav/wavehdr.h"
#include "wtk/os/wtk_lock.h"
#include "wtk_sterblist.h"
#ifdef __cplusplus
extern "C" {
#endif
/**
 * stereo wave file. only write and flush is thread-safe;
 */
typedef struct wtk_sterfile wtk_sterfile_t;


struct wtk_sterfile
{
	wtk_lock_t lock;		//used for multi-thread write.
	WaveHeader hdr;
	wtk_sterblist_t *blist;
	FILE *file;
	int writed;
	int max_pend;
	int pending;
};

wtk_sterfile_t* wtk_sterfile_new(int sample_rate);
int wtk_sterfile_delete(wtk_sterfile_t *f);
int wtk_sterfile_init(wtk_sterfile_t *f,int sample_rate);
int wtk_sterfile_clean(wtk_sterfile_t *f);
int wtk_sterfile_open(wtk_sterfile_t *f,char *fn);
int wtk_sterfile_close(wtk_sterfile_t *f);
int wtk_sterfile_flush(wtk_sterfile_t *f);
int wtk_sterfile_flush_pend_data(wtk_sterfile_t *f);
int wtk_sterfile_write(wtk_sterfile_t *f,short *data,int samples,int is_left_channel);
#ifdef __cplusplus
};
#endif
#endif
