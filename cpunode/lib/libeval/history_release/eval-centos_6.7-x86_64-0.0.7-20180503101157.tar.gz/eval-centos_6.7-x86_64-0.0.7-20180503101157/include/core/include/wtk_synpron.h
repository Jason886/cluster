/*
 * wtk_synpron.h
 *
 *  Created on: Jun 5, 2015
 *      Author: dm
 */
#ifdef USE_NEW_DICT
#ifndef WTK_SYNPRON_H_
#define WTK_SYNPRON_H_
#include "wtk/core/wtk_heap.h"
#include "wtk/core/wtk_strbuf.h"
#include "wtk/l2s/wtk_dict_handler_cfg.h"
#include "wtk/vite/model/wtk_dict.h"
#ifdef __cplusplus
extern "C"{
#endif
typedef struct wtk_synparser wtk_synparser_t;
typedef void* (*wtk_synpron_query_f)(void*, wtk_strbuf_t* buf);
typedef void* (*wtk_synpron_query_f2)(void*, char* data, int len);

typedef enum{
//	WTK_WORD_UNINIT=0,         // not initial, contain auto add, e.g. sil/<s>/</s>/<!SENT_START>/!SENT_END/!NULL when don't in dict_file.
	WTK_WORD_BASE,             // exist in base dictionary
	WTK_WORD_DEFORM,           // generate by deforming word in base dictionary
	WTK_WORD_CHN               // Chinese which are auto-gen.
//	WTK_WORD_DUMMY             // generate by dummy phones
}wtk_word_type_t;
typedef enum {
	SYN_NO,    //no syn. for response wtk_word_type_t
	SYN_SES,   //s/es
	SYN_ED,    // word end with "ed", following same.
	SYN_ING,   // "ing"
	SYN_TION,  // "tion"
	SYN_NESS,  // "ness"
	SYN_LESS,  // "less"
	SYN_OR,    // "or"
	SYN_ER,    // "er"
	SYN_EST,   // "est"
//	SYN_LY,    // "ly"
	SYN_Y,     // "y"  merge "ly"
	SYN_APTS,  // "\'s|\'"
	SYN_COMB,  // two words combination
	SYN_STRIP  // strip symbol
//	SYN_TONE   // tone pron
}wtk_syn_type_t;
typedef struct{
	wtk_word_type_t wrd_t;       //词的发音获取方式
	wtk_syn_type_t syn_t;        //生成规则类别
	unsigned int isbase:1;       //单词是否作为基本词,基本词才可以生成其它词
	unsigned int istone:1;      //记录是否存在浊化发音
}wtk_word_ext_info_t;

struct  wtk_synparser{
	wtk_dict_handler_cfg_t* cfg;
	wtk_dict_t* dict;            //dynamic dict.
	wtk_heap_t* heap;
	wtk_strbuf_t* buf;
	wtk_synpron_query_f syn_f;
	void* ths;            // for the first parameter of wtk_synpron_query_f
	wtk_array_t* phns;
	wtk_array_t* sylls;
	wtk_array_t* chars;

	wtk_array_t* addphns;   // 针对于原型词发音，需要添加的额外的发音音素
	/*
	 * 针对于原型词发音，需要删除其中的音素,位置顺序delphns[0...n]对应于word尾部音素.
	 * 如: luminate l uw m ih n ey t, 如果delphns为"ey t",那么生成发音时luminate只保留l uw m ih n
	 * */
	wtk_array_t* delphns;

	wtk_array_t* combwrds; //用于复合词的分割保存
	wtk_array_t* combprons; //用于复合词的发音保存
};

wtk_synparser_t* wtk_synparser_new(wtk_dict_handler_cfg_t* cfg, wtk_dict_t *d, wtk_synpron_query_f f, void *ths);
int wtk_synparser_reset(wtk_synparser_t* p);
void wtk_synparser_delete();

wtk_dict_word_t* wtk_synpron_word_copy(wtk_dict_t* d, wtk_synparser_t* p, wtk_dict_word_t* w, wtk_string_t*name, int spsil);
void wtk_synpron_word_add_spsil(wtk_dict_t* d, wtk_synparser_t* p, wtk_dict_word_t* word);
wtk_dict_pron_t* wtk_synpron_new_pron(wtk_dict_t* d, wtk_dict_word_t *word, wtk_dict_pron_t* pron,
		wtk_synparser_t* p, wtk_array_t* ext_phns, wtk_array_t* delphns);
wtk_dict_pron_t* wtk_synpron_pron_copy(wtk_dict_t* d, wtk_dict_word_t *word, wtk_dict_pron_t* pron,
		wtk_synparser_t* p);
int wtk_synpron_add_tone(wtk_dict_t* d, wtk_synparser_t* p, wtk_dict_word_t* w);

wtk_dict_word_t* wtk_synpron_chn_get_word(wtk_synparser_t* p, char* data, int len);
wtk_dict_word_t* wtk_synpron_find(wtk_synparser_t* parser,char* data, int len);
wtk_dict_word_t* wtk_synpron_chn_find(wtk_synparser_t* parser, char* data, int len);
#ifdef __cplusplus
};
#endif
#endif /* WTK_SYNPRON_H_ */
#endif /* USE_NEW_DICT */
