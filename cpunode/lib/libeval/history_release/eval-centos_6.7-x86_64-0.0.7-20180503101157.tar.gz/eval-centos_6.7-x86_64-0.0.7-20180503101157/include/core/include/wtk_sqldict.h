#ifndef WTK_EVAL_UTIL_WTK_SQLDICT_H_
#define WTK_EVAL_UTIL_WTK_SQLDICT_H_
#include "wtk_dict.h"
#include "wtk_sqlite.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_sqldict wtk_sqldict_t;
#define wtk_sqldict_get_word_s(s,w) wtk_sqldict_get_word(s,w,sizeof(w)-1)
struct wtk_sqldict
{
	wtk_label_t *label;
	wtk_dict_t *dict;
	wtk_sqlite_t *sql;
};

wtk_sqldict_t* wtk_sqldict_new(char* fn);
int wtk_sqldict_delete(wtk_sqldict_t *s);
int wtk_sqldict_reset(wtk_sqldict_t *s);
/**
 * @brief 通过查找字典和sql数据库找到精确单词发音
 */
wtk_dict_word_t* wtk_sqldict_get_word(wtk_sqldict_t *s,char *w,int bytes);
/**
 * @brief 通过查找字典和sql模糊匹配的方式查找单词发音,找不到就随机给发音
 */
wtk_dict_word_t* wtk_sqldict_get_word2(wtk_sqldict_t *s,char *w,int bytes);
/**
 * @brief 通过查找字典和sql模糊匹配的方式查找单词发音
 */
wtk_dict_word_t* wtk_sqldict_get_like_word(wtk_sqldict_t *s,char *w,int bytes);

#ifdef __cplusplus
};
#endif
#endif
