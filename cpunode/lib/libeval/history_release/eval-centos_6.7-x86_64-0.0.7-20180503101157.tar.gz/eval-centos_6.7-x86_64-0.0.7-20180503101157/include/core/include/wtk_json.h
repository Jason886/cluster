#ifndef WTK_CORE_WTK_JSON_H_
#define WTK_CORE_WTK_JSON_H_
#include "wtk_type.h"
#include "wtk_queue.h"
#include "wtk_array.h"
#include "wtk_heap.h"
#include "wtk_strbuf.h"
#include "wtk_str_parse.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_json wtk_json_t;
typedef struct wtk_json_item wtk_json_item_t;
//typedef struct wtk_json_parser wtk_json_parser_t;
#define wtk_json_obj_add_ref_str_s(json,item,k,v) wtk_json_obj_add_ref_str(json,item,k,sizeof(k)-1,v)
#define wtk_json_obj_add_str_s(json,item,k,v) wtk_json_obj_add_str(json,item,k,sizeof(k)-1,v)
#define wtk_json_obj_add_ref_number_s(json,item,k,number) wtk_json_obj_add_ref_number(json,item,k,sizeof(k)-1,number)
#define wtk_json_obj_add_item2_s(json,obj,k,item) wtk_json_obj_add_item2(json,obj,k,sizeof(k)-1,item)
#define wtk_json_obj_get_s(obj,k) wtk_json_obj_get(obj,k,sizeof(k)-1)

typedef enum
{
	WTK_JSON_FALSE,
	WTK_JSON_TRUE,
	WTK_JSON_NULL,
	WTK_JSON_STRING,
	WTK_JSON_NUMBER,
	WTK_JSON_ARRAY,
	WTK_JSON_OBJECT,
}wtk_json_item_type_t;

typedef struct
{
	wtk_queue_node_t q_n;
	wtk_string_t k;
	wtk_json_item_t *item;
}wtk_json_obj_item_t;

typedef struct
{
	wtk_queue_node_t q_n;
	wtk_json_item_t *item;
}wtk_json_array_item_t;

struct wtk_json_item
{
	wtk_json_item_type_t type;
	union{
		double number;
		wtk_string_t *str;
		wtk_queue_t *array;		//wtk_json_array_item_t
		wtk_queue_t *object;	//wtk_json_obj_item_t
	}v;
};

struct wtk_json
{
	wtk_heap_t *heap;
	wtk_json_item_t  *main;
};


wtk_json_t* wtk_json_new();
void wtk_json_delete(wtk_json_t *json);
void wtk_json_reset(wtk_json_t *json);

wtk_json_item_t* wtk_json_new_item(wtk_json_t *json,wtk_json_item_type_t type);
wtk_json_item_t* wtk_json_new_number(wtk_json_t *json,double v);
wtk_json_item_t* wtk_json_new_string(wtk_json_t *json,char *data,int len);
wtk_json_item_t* wtk_json_new_array(wtk_json_t *json);
wtk_json_item_t* wtk_json_new_object(wtk_json_t *json);

wtk_json_item_t* wtk_json_obj_get(wtk_json_item_t *obj,char *key,int key_bytes);
wtk_json_obj_item_t* wtk_json_new_obj_item(wtk_json_t *json,char *key,int key_bytes,wtk_json_item_t *item);
void wtk_json_obj_add_item(wtk_json_t *json,wtk_json_item_t *obj,wtk_json_obj_item_t *item);
void wtk_json_obj_add_item2(wtk_json_t *json,wtk_json_item_t *obj,char *key,int key_bytes,wtk_json_item_t *item);
void wtk_json_obj_set_last_item_value(wtk_json_t *json,wtk_json_item_t *obj,wtk_json_item_t *item);
void wtk_json_obj_add_ref_str(wtk_json_t *json,wtk_json_item_t *obj,char *key,int key_len,wtk_string_t *v);
void wtk_json_obj_add_str(wtk_json_t *json,wtk_json_item_t *obj,char *key,int key_len,wtk_string_t *v);
void wtk_json_obj_add_ref_number(wtk_json_t *json,wtk_json_item_t *obj,char *key,int key_len,double number);

void wtk_json_array_add_item(wtk_json_t *json,wtk_json_item_t *array,wtk_json_item_t *item);
void wtk_json_array_add_ref_str(wtk_json_t *json,wtk_json_item_t *array,wtk_string_t *v);
void wtk_json_array_add_ref_number(wtk_json_t *json,wtk_json_item_t *array,double v);
wtk_json_item_t* wtk_json_array_get(wtk_json_item_t* item,int idx);

//---------------------------------------------
void wtk_json_print(wtk_json_t *json,wtk_strbuf_t *buf);
void wtk_json_item_print(wtk_json_item_t *item,wtk_strbuf_t *buf);
void wtk_json_item_print3(wtk_json_item_t *item);
#ifdef __cplusplus
};
#endif
#endif
