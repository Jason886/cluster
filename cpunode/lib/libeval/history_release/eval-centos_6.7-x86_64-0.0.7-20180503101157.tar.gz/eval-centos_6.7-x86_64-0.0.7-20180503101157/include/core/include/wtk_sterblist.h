#ifndef WTK_AUDIO_WTK_STERBLIST_H_
#define WTK_AUDIO_WTK_STERBLIST_H_
#include "wtk/core/wtk_type.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_sterblist wtk_sterblist_t;
typedef struct wtk_sterblock wtk_sterblock_t;

struct wtk_sterblock
{
	wtk_sterblock_t *next;
	short *data;
	int left_pos;
	int right_pos;
	int samples;
};

struct wtk_sterblist
{
	wtk_sterblock_t *blk_cache;
	wtk_sterblock_t *left_blk;
	wtk_sterblock_t *right_blk;
	wtk_sterblock_t *blk_list;
	int blk_samples;
};

wtk_sterblock_t* wtk_sterblock_new(int samples);
void wtk_sterblock_reset(wtk_sterblock_t *b);
void wtk_sterblock_delete(wtk_sterblock_t *b);
int wtk_sterblock_is_full(wtk_sterblock_t *b);
wtk_sterblist_t* wtk_sterblist_new(int blk_samples);
void wtk_sterblist_delete(wtk_sterblist_t *l);
void wtk_sterblist_push_left(wtk_sterblist_t *l,short data);
void wtk_sterblist_push_right(wtk_sterblist_t *l,short data);
void wtk_sterblist_pop_first_blk(wtk_sterblist_t *l);
#ifdef __cplusplus
};
#endif
#endif
