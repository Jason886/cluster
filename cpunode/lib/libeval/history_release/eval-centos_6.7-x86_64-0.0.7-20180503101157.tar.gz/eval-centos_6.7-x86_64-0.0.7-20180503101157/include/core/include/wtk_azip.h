#ifndef WTK_CORE_AZIP_WTK_AZIP_H_
#define WTK_CORE_AZIP_WTK_AZIP_H_
#include "wtk_type.h"
#include "wtk_azip_cfg.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_azip wtk_azip_t;

struct wtk_azip
{
	wtk_azip_cfg_t *cfg;
	unsigned long low;
	unsigned long high;	//[low,high]
	unsigned long *freq;
	unsigned long tot_freq;
	wtk_strbuf_t *buf;
	int bits_to_follow;
	unsigned char byte;
	int nbit;
};

wtk_azip_t* wtk_azip_new(wtk_azip_cfg_t *cfg);
void wtk_azip_delete(wtk_azip_t *z);
void wtk_azip_reset(wtk_azip_t *z);

int wtk_azip_feed(wtk_azip_t *z,int eof,unsigned char *data,int bytes);
#ifdef __cplusplus
};
#endif
#endif
