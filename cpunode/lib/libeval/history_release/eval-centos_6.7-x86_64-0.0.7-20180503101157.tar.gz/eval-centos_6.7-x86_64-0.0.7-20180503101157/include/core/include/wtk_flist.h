#ifndef WTK_UTIL_WTK_FLIST_H_
#define WTK_UTIL_WTK_FLIST_H_
#include "wtk_str.h"
#include "wtk_heap.h"
#include "wtk_queue.h"
#include "wtk_strbuf.h"
#include "wtk_os.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_flist wtk_flist_t;

typedef enum
{
	WTK_FITEM_START,
	WTK_FITEM_APPEND,
}wtk_fitem_state_t;

typedef struct
{
	wtk_queue_node_t q_n;
	wtk_string_t *str;
}wtk_fitem_t;

struct wtk_flist
{
	wtk_queue_t queue;
	wtk_heap_t *heap;
	wtk_strbuf_t *buf;
	wtk_fitem_state_t state;
};

wtk_flist_t* wtk_flist_new(char *fn);
int wtk_flist_delete(wtk_flist_t *fl);

typedef void(*wtk_flist_notify_f)(void *ths,char *fn);
void wtk_flist_process(char *fn,void *ths,wtk_flist_notify_f notify);
#ifdef __cplusplus
};
#endif
#endif
