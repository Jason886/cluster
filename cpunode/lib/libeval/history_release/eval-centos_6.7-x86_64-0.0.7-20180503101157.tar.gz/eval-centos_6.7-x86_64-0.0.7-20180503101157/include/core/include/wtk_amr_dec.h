#ifndef WTK_AMR_DEC_H_
#define WTK_AMR_DEC_H_
#include "wtk/core/wtk_strbuf.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*wtk_amr_dec_write_f)(void *hook,char *buf,int size);

typedef enum wtk_amr_dec_state
{
    WTK_AMR_DEC_CHECK_HEADER = 0,
    WTK_AMR_DEC_READ_FRAME_LEN,
    WTK_AMR_DEC_READ_FRAME_DATA,
}wtk_amr_dec_state_t;

typedef enum wtk_amr_type
{
    WTK_AMR_NB = 0,
    WTK_AMR_WB,
}wtk_amr_type_t;

typedef struct wtk_amr_dec
{
    void *amr;          /* decoder pointer */
    int  data_len;      /* frame or header length */
    wtk_strbuf_t *buf;  /* frame data */
    wtk_amr_dec_write_f write; /* write out buffer */
    void  *hook;
    wtk_amr_type_t      amr_type; /* amrwb or amrnb */
    wtk_amr_dec_state_t state;    /* decode state */
}wtk_amr_dec_t;

wtk_amr_dec_t * wtk_amr_new();
void wtk_amr_delete(wtk_amr_dec_t *dec);

int wtk_amr_start(wtk_amr_dec_t *dec, wtk_amr_type_t type, wtk_amr_dec_write_f write, void *hook);
int wtk_amr_decode(wtk_amr_dec_t *dec, int len, char *data);
int wtk_amr_stop(wtk_amr_dec_t *dec);

#ifdef __cplusplus
}
#endif
#endif
