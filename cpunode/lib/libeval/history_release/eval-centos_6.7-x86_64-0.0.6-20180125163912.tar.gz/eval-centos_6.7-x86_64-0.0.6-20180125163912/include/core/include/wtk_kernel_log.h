/**
 * @file    wtk_kernel_log.h
 * @brief
 *
 *  This file implements interfaces declared in file wtk_kernel_log.h.
 *
 * @author     jfyuan
 * @version    1.0
 * @date       2015-09-14
 * @see
 *
 * <b>History:</b><br>
 * <table>
 *  <tr> <th>Version    <th>Date        <th>Author  <th>Notes</tr>
 *  <tr> <td>1.0        <td>2015-09-14  <td>jfyuan  <td>Create this file</tr>
 * </table>
 *
 */
#ifndef WTK_COM_LOG_WTK_KERNEL_LOG_H_
#define WTK_COM_LOG_WTK_KERNEL_LOG_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NDEBUG
#include "wtk_log.h"

wtk_log_t *wtk_kernel_log_new(int level);
void wtk_kernel_log_delete(wtk_log_t* log);
int wtk_kernel_log_printf(const char *func,int line,int level,char* fmt,...);
#define wtk_kernel_log_log(l,fmt,...) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_NOTICE,fmt,__VA_ARGS__) : wtk_kernel_log_printf(__FUNCTION__,__LINE__,LOG_NOTICE,fmt,__VA_ARGS__))
#define wtk_kernel_log_log0(l,fmt) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_NOTICE,fmt) : wtk_kernel_log_printf(__FUNCTION__,__LINE__,LOG_NOTICE,fmt))
#define wtk_kernel_log_warn(l,fmt,...) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_WARN,fmt,__VA_ARGS__) : wtk_kernel_log_printf(__FUNCTION__,__LINE__,LOG_WARN,fmt,__VA_ARGS__))
#define wtk_kernel_log_warn0(l,fmt) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_WARN,fmt) : wtk_kernel_log_printf(__FUNCTION__,__LINE__,LOG_WARN,fmt))
#define wtk_kernel_log_err(l,fmt,...) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_ERR,fmt,__VA_ARGS__) : wtk_kernel_log_printf(__FUNCTION__,__LINE__,LOG_ERR,fmt,__VA_ARGS__))
#define wtk_kernel_log_err0(l,fmt) (l ? wtk_log_printf(l,__FUNCTION__,__LINE__,LOG_ERR,fmt) : wtk_kernel_log_err0(__FUNCTION__,__LINE__,LOG_ERR,fmt))
#else
#define wtk_kernel_log_new(level) NULL
#define wtk_kernel_log_delete(log)
#define wtk_kernel_log_log(l,fmt,...)
#define wtk_kernel_log_log0(l,fmt)
#define wtk_kernel_log_warn(l,fmt,...)
#define wtk_kernel_log_warn0(l,fmt)
#define wtk_kernel_log_err(l,fmt,...)
#define wtk_kernel_log_err0(l,fmt)

#endif /* #ifndef NDEBUG */

#ifdef __cplusplus
};
#endif
#endif
