#ifndef WTK_MATH_WTK_MATH_H_
#define WTK_MATH_WTK_MATH_H_
#include <math.h>
#include "wtk_vector.h"
#include "wtk_source.h"
#include "wtk_matrix.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef PI
#undef PI                /* PI is defined in Linux */
#endif
#define PI   3.14159265358979
#define TPI  6.28318530717959     /* PI*2 */
#define LZERO  (-1.0E10)   /* ~log(0) */
#define LSMALL (-0.5E10)   /* log values < LSMALL are set to LZERO */
#define MINEARG (-708.3)   /* lowest exp() arg  = log(MINLARG) */
#define MINLARG 2.45E-308  /* lowest log() arg  = exp(MINEARG) */

/* ZeroMeanFrame: remove dc offset from given vector */
void wtk_vector_zero_mean_frame(wtk_vector_t* v);
void wtk_vector_pre_emphasise(wtk_vector_t* v,float k);
wtk_vector_t* wtk_math_create_ham_window(int frame_size);
void wtk_realft (wtk_vector_t* s);
void wtk_math_do_diff(wtk_vector_t** pv,int window_size,double sigma,int start_pos,int step);
void wtk_math_do_simple_diff(wtk_vector_t** pv,int window_size,int start_pos,int step);

int wtk_source_read_vector(wtk_source_t* s,wtk_vector_t* v,int bin);
int wtk_source_read_matrix(wtk_source_t *s,wtk_matrix_t *m,int bin);
int wtk_source_read_short_matrix(wtk_source_t *s, wtk_matrix_t *m, int bin, float scale);
int wtk_source_read_hlda(wtk_source_t *s,wtk_matrix_t **pm);
int wtk_hlda_read(wtk_matrix_t **pm,wtk_source_t *s);
int wtk_source_read_hlda_bin(wtk_matrix_t **pm,wtk_source_t *s);
void wtk_matrix_multiply_vector(wtk_vector_t *dst,wtk_matrix_t *m,wtk_vector_t *src);
int wtk_floatfix_q(float max,float min,int n);
#ifdef __cplusplus
};
#endif
#endif
