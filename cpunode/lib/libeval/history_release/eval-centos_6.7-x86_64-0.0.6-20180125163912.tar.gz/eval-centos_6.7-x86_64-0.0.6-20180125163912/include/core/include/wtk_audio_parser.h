#ifndef WTK_AUDIO_WTK_AUDIO_PARSER_H_
#define WTK_AUDIO_WTK_AUDIO_PARSER_H_
#include "wtk/core/wtk_type.h"
#include "wtk_decode.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_audio_parser wtk_audio_parser_t;
typedef int (*wtk_audio_parser_read_handler_t)(void *hook,uint8_t *buf,int buf_size);
typedef int (*wtk_audio_parser_write_handler_t)(void *hook,char *buf,int buf_size);
typedef int (*wtk_audio_parser_done_handler_t)(void *hook);


struct wtk_audio_parser
{
	void *io_ctx;
	int input_size;
	int output_size;
	char *input;
	char *output_alloc;
	short *output;
	//read write callback section;
	void *hook;//	struct wtk_audio_decoder *dec;
	wtk_audio_parser_read_handler_t read;
	wtk_audio_parser_write_handler_t write;
	wtk_audio_parser_done_handler_t done;
	//audio type;
	char *audio_type;   //"mp3","flv"
	int code_id;
	unsigned use_ogg:1;
    unsigned use_spx:1;
    unsigned use_amr:1;
};

wtk_audio_parser_t* wtk_audio_parser_new(void *hook,wtk_audio_parser_read_handler_t read,wtk_audio_parser_write_handler_t write,wtk_audio_parser_done_handler_t done);
int wtk_audio_parser_delete(wtk_audio_parser_t *p);
int wtk_audio_parser_prepare(wtk_audio_parser_t *d,int type);
int wtk_audio_parser_run(wtk_audio_parser_t* d);
#ifdef __cplusplus
};
#endif
#endif
