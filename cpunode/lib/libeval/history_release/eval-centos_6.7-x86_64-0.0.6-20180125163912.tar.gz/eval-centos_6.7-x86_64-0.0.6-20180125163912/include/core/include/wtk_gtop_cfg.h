#ifndef WTK_G2P_WTK_GTOP_CFG_H_
#define WTK_G2P_WTK_GTOP_CFG_H_
#include "wtk_local_cfg.h"
#include "wtk_source.h"
#include "wtk_dummypron_cfg.h"
#ifdef __cplusplus
extern "C" {
#endif

#define USE_PERMANENT_PRON 0
#define USE_LETTERS_PRON 1
#define USE_TRIRULES_PRON 2
typedef struct wtk_gtop_cfg wtk_gtop_cfg_t;

struct wtk_gtop_cfg
{
	unsigned use_dummypron:1;
	wtk_dummypron_cfg_t dummypron;
	
	wtk_string_t sep;			//for delimiters in snt
	unsigned use_oov_pron:1;	//0, use [s|ax|t|n|ih] as word prons;1,use letters's pron of word as word prons;2,use tri-letters rules make prons
};

int wtk_gtop_cfg_init(wtk_gtop_cfg_t* cfg);
int wtk_gtop_cfg_clean(wtk_gtop_cfg_t* cfg);
int wtk_gtop_cfg_update(wtk_gtop_cfg_t* cfg,wtk_source_loader_t *sl);
int wtk_gtop_cfg_update_local(wtk_gtop_cfg_t* cfg,wtk_local_cfg_t *lc);

int wtk_gtop_cfg_has_sep(wtk_gtop_cfg_t *cfg, wtk_string_t *str);
#ifdef __cplusplus
};
#endif
#endif
