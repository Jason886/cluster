#ifndef WTK_NOSQLDICT_H_
#define WTK_NOSQLDICT_H_

#include "wtk_dict.h"

#ifdef __cplusplus
extern "C" {
#endif

struct  wtk_nosqldict;

struct wtk_nosqldict* wtk_nosqldict_new(const char* fn);
int wtk_nosqldict_delete(struct wtk_nosqldict *ns);
int wtk_nosqldict_reset(struct wtk_nosqldict *ns);
struct wtk_dict_word* wtk_nosqldict_get_word(struct wtk_nosqldict *ns, const char *word, int len);
struct wtk_dict* wtk_nosqldict_get_dict(struct wtk_nosqldict *ns);

#ifdef __cplusplus
}
#endif
#endif
