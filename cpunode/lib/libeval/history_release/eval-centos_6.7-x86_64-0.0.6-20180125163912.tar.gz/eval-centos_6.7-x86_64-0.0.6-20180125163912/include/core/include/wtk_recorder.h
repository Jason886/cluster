#ifndef WTK_AUDIO_WTK_RECORDER_H_
#define WTK_AUDIO_WTK_RECORDER_H_
#ifdef OPENAL
#include <AL/al.h>
#include <AL/alc.h>
#else
#include <unistd.h>
#include <alsa/asoundlib.h>
#endif
#include "wtk/core/wtk_type.h"
#include "wtk/core/wtk_strbuf.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_recorder wtk_recorder_t;

struct wtk_recorder
{
#ifdef OPENAL
	ALCdevice *device;
#else
	snd_pcm_t *handler;
#endif
	wtk_strbuf_t *buf;
	int time;	//ms;
};

wtk_recorder_t* wtk_recorder_new(int sample_rate,int buff_time);
int wtk_recorder_delete(wtk_recorder_t *r);
int wtk_recorder_init(wtk_recorder_t* r,int sample_rate,int buff_time);
int wtk_recorder_clean(wtk_recorder_t* r);
int wtk_recorder_start(wtk_recorder_t *r);
int wtk_recorder_stop(wtk_recorder_t *r);
wtk_strbuf_t* wtk_recorder_read(wtk_recorder_t *r);
#ifdef __cplusplus
};
#endif
#endif
