/*
 * wtk_conn.h
 *
 *  Created on: Jun 4, 2015
 *      Author: dm
 */
#ifdef USE_NEW_DICT
#ifndef WTK_CONN_H_
#define WTK_CONN_H_
#include "wtk/l2s/wtk_dict_handler_cfg.h"
#include "wtk/vite/model/wtk_dict.h"
#include "wtk/core/text/wtk_txtparser.h"
#include "wtk/vite/net/wtk_lat.h"
#include "third/json/cJSON.h"
#ifdef __cplusplus
extern "C"{
#endif
typedef struct wtk_conn wtk_conn_t;
typedef struct wtk_conn_phone wtk_conn_phone_t;
typedef struct wtk_conn_pron wtk_conn_pron_t;
typedef struct wtk_conn_wrd wtk_conn_wrd_t;
typedef struct wtk_conn_connwrds wtk_conn_connwrds_t;
typedef int (*wtk_conn_wrd_restore_f)(void* ths, void* wrd);
typedef struct wtk_conn_vphone wtk_conn_vphone_t;
struct wtk_conn_vphone{
	wtk_queue_node_t n;
	int num;
	wtk_string_t *name;
};
struct wtk_conn_phone{
	wtk_queue_node_t n;
	wtk_dict_phone_t* phone;                 //dict phone
	int num;                                     // number of phone[wtk_dict_phone_t]
	wtk_string_t* name;                          // ipa88 phone name
	wtk_string_t* vname;                         // vary ipa88 phone name, when continue speech,
	wtk_queue_t vphone;                          //wtk_conn_vphone_t, saving all varied kinds of vname.
	wtk_phoneme_type_t type;
};

struct wtk_conn_pron{
	wtk_queue_node_t n;                     //link pron[wtk_conn_pron_t]
	wtk_dict_pron_t* pron;                  //dict pron
	wtk_conn_phone_t* first;               //show initial kind when appear continue speech
	wtk_conn_phone_t* tail;          //show initial kind when appear continue speech
	unsigned first_is_vary;                 //indicate first var whether vary.
	unsigned tail_is_vary;
};

struct wtk_conn_wrd{
	wtk_dict_word_t* wrd;                   //dict word
	wtk_string_t* name;                     //new name, identify diff name for same word when exist diff pron.
	wtk_queue_t q;                          //new pron queue
	int alter;                              //whether dict word pron alter in current context.
	int only_conn;                          //must be continue speech
};

struct wtk_conn_connwrds{
	wtk_string_t *w1;
	wtk_string_t *w2;
};
struct wtk_conn{
	wtk_dict_handler_cfg_t* cfg;
	wtk_label_t* label;
	wtk_dict_t* dict;              // base dict
	wtk_dict_t* wrd_dict;          // new dict support continue speech.
	wtk_str_hash_t* pron_h;            // for drip redundancy pron
	wtk_str_hash_t* wrd_h;             // saving element[wtk_conn_wrd_t*]. unique element.
//	wtk_array_t* wrds;                 // array of element[wtk_conn_wrd_t*], for check continue speech.
	wtk_heap_t* heap;
	wtk_strbuf_t *buf;
//	wtk_array_t *tmp_arr;              // [wtk_string_t*]temper saving space for building a new pron, as buf.
	unsigned int only_conn:1;          //only continue speech

	/**
	 * find dict word according restore words which added number.
	 * wrdnum used to change word according to add number.
	 */
	wtk_conn_wrd_restore_f wrd_restore_f;
	void *wrd_restore_ths;
	int wrdnum;

	wtk_array_t *word_conn;                  //for outer input words array which must be continue speech
	wtk_array_t *word_no_conn;               //for outer input words array which is not continue speech
};

/**
 * 描述:
 *  dict  发音词典, 内容讲不会修改，只用于查询获取发音
 *  label 该标记容器内容将不会被修改，只用于查询
 *　　cfg 记录了连读的设置参数，如use_only_conti, 另外会使用到公用的数据res.
 */
wtk_conn_t* wtk_conn_new(wtk_dict_handler_cfg_t* cfg, wtk_dict_t* dict, wtk_label_t* label);
int wtk_conn_reset(wtk_conn_t* cs);
int wtk_conn_delete(wtk_conn_t* cs);

wtk_conn_pron_t* wtk_conn_pron_new(wtk_dict_pron_t* pron, wtk_heap_t* heap);
wtk_conn_phone_t* wtk_conn_phone_new(wtk_dict_phone_t* phone, wtk_string_t* name, wtk_heap_t* heap, wtk_str_hash_t* hash, int num);
wtk_conn_wrd_t* wtk_conn_wrd_new(wtk_conn_t* cs, wtk_string_t* name, wtk_dict_word_t* wrd);

int wtk_conn_wrd_check(wtk_conn_t* cs, wtk_conn_wrd_t* prev, wtk_conn_wrd_t* next);
wtk_dict_word_t* wtk_conn_dict_wrd_new(wtk_conn_t* cs, wtk_conn_wrd_t* wrd, int only_conti);
wtk_conn_wrd_t* wtk_conn_push_wrd2(wtk_conn_t* cs, wtk_string_t* w, wtk_dict_word_t* dw);

int wtk_conn_lat_proc(wtk_conn_t* cs, wtk_lat_t* lat);
void wtk_conn_lat_restore(wtk_array_t* arr, wtk_lat_t* lat);
void wtk_conn_set_wrd_restore_callback(wtk_conn_t* cs, wtk_conn_wrd_restore_f restore, void* ths);

/*
 * check two words needed continue speech.
 * 1 means of need, or 0 means of no.
 */
int wtk_conn_match(wtk_array_t *wordarr, wtk_string_t *w1, wtk_string_t* w2);

void wtk_conn_set(wtk_conn_t* cs, wtk_dict_handler_cfg_t* cfg, cJSON* json);

/*
 * return: 1 means of no continue speech, or 0.
 */
int conn_alph_phn(wtk_conn_t* cs, wtk_string_t* name, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
int conn_phn_phn(wtk_conn_t* cs, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
int conn_same_phntype(wtk_conn_t* cs, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
int conn_csont_vowel(wtk_conn_t* cs, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
int conn_vowel_vowel(wtk_conn_t* cs, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
int conn_csont_csont(wtk_conn_t* cs, wtk_conn_pron_t* prev, wtk_conn_pron_t* next);
wtk_dict_pron_t* wtk_conn_add_pron_unique(wtk_conn_t *cs, wtk_dict_word_t *w,
		wtk_string_t *outsym, wtk_string_t **phones, int nphones, float prob);
void wtk_conn_print(wtk_conn_t *cs, wtk_array_t* arr);
void wtk_conn_pron_print(wtk_conn_pron_t* pron);
#ifdef __cplusplus
};
#endif
#endif /* WTK_CONN_H_ */
#endif /* USE_NEW_DICT */
