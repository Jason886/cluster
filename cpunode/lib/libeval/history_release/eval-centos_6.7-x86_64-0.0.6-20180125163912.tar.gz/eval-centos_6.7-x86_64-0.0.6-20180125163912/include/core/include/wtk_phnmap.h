/*
 * wtk_phnmap.h
 *
 *  Created on: Apr 1, 2015
 *      Author: dm
 */

#ifndef WTK_PHNMAP_H_
#define WTK_PHNMAP_H_

#include "wtk_source.h"
#include "wtk_heap.h"
#include "wtk_str_hash.h"
#include "wtk_strbuf.h"
#ifdef __cplusplus
extern "C"{
#endif
#define wtk_phnmap_phn2ipa_s(map, s) wtk_phnmap_ipa2phn(map, s, sizeof(s)-1)
#define wtk_phnmap_ipa2phn_s(map, s) wtk_phnmap_ipa2phn(map, s, sizeof(s)-1)
#define wtk_phnmap_phn2chn_s(map, s) wtk_phnmap_phn2chn(map, s, sizeof(s)-1)
#define wtk_phnmap_chn2phn_s(map, s) wtk_phnmap_chn2phn(map, s, sizeof(s)-1)
typedef struct wtk_phnmap wtk_phnmap_t;

struct wtk_phnmap{
	wtk_str_hash_t *hash;      // key[phone]->value[ipa88]
	wtk_str_hash_t *rev_hash;  //reverse, key[ipa88]->key[phone]
	wtk_heap_t *heap;
	wtk_strbuf_t *buf;
	unsigned use_rev;          //control reverse, default 0.
};


wtk_phnmap_t* wtk_phnmap_new(int reverse, int h);
wtk_phnmap_t* wtk_phnmap_new2();
int wtk_phnmap_load(wtk_phnmap_t* map, wtk_source_t* s);
int wtk_phnmap_delete(wtk_phnmap_t *map);
wtk_string_t *wtk_phnmap_phn2ipa(wtk_phnmap_t *map, char* s, int l);
wtk_string_t *wtk_phnmap_ipa2phn(wtk_phnmap_t *map, char* s, int l);
wtk_array_t* wtk_phnmap_ipa2phn2(wtk_phnmap_t *map, char* s, int l, wtk_heap_t *heap);
wtk_string_t *wtk_phnmap_phn2chn(wtk_phnmap_t *map, char* s, int l);
wtk_string_t *wtk_phnmap_chn2phn(wtk_phnmap_t *map, char* s, int l);
wtk_array_t* wtk_phnmap_chn2phn2(wtk_phnmap_t *map, char* s, int l, wtk_heap_t *heap);

//---------------test and output------------------
int wtk_phnmap_print(wtk_phnmap_t *map);

#ifdef __cplusplus
};
#endif


#endif /* WTK_PHNMAP_H_ */
