#ifndef WTK_CORE_AZIP_WTK_AZIP_CFG_H_
#define WTK_CORE_AZIP_WTK_AZIP_CFG_H_
#include "wtk_local_cfg.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_azip_cfg wtk_azip_cfg_t;
struct wtk_azip_cfg
{
	unsigned long max_value;
	unsigned long half_value;
	unsigned long first_q_value;
	unsigned long third_q_value;
	wtk_string_t model;
};

int wtk_azip_cfg_init(wtk_azip_cfg_t *cfg);
int wtk_azip_cfg_clean(wtk_azip_cfg_t *cfg);
int wtk_azip_cfg_update_local(wtk_azip_cfg_t *cfg,wtk_local_cfg_t *lc);
int wtk_azip_cfg_update(wtk_azip_cfg_t *cfg);
#ifdef __cplusplus
};
#endif
#endif
