#ifndef WTK_G2P_WTK_GTOP_H_
#define WTK_G2P_WTK_GTOP_H_
#include "wtk_txtparser.h"
#include "wtk_gtop_cfg.h"
#include "wtk_dummypron.h"
#include "time.h"
#include "ctype.h"
#include "wtk_dict.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_gtop wtk_gtop_t;


struct wtk_gtop
{
	wtk_gtop_cfg_t *cfg;
	wtk_heap_t *heap;
	
	wtk_dict_word_find_f get_word;
	void *data;

	wtk_dummypron_t *dummypron;
	wtk_txtparser_t *txtparser;
	wtk_dict_t *dict;

	wtk_strbuf_t *buf;

	wtk_str_hash_t *notdictword;

	unsigned res_type:1;

};

wtk_gtop_t* wtk_gtop_new(wtk_gtop_cfg_t *cfg, void *get_word, void *data, wtk_dict_t *dict, int res_type);
int wtk_gtop_delete(wtk_gtop_t* gp);
int wtk_gtop_reset(wtk_gtop_t *gp);
int wtk_gtop_txtparser_post(wtk_gtop_t *gp, wtk_txtparser_t *tp);
wtk_dict_word_t* wtk_gtop_process(wtk_gtop_t* gp, char *wrd, int bytes);
wtk_dict_word_t* wtk_gtop_process_minires(wtk_gtop_t* gp, char *wrd, int bytes);
#ifdef __cplusplus
};
#endif
#endif
