#ifndef WTK_EVAL_ERRNO_WTK_ERRNO_H_
#define WTK_EVAL_ERRNO_WTK_ERRNO_H_
#include "wtk_type.h"
#include "wtk_strbuf.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct wtk_errno wtk_errno_t;
#define wtk_errno_set_no(e,n) ((e)->no=no)
#define wtk_errno_set_s(e,s) wtk_errno_set((e),s,sizeof(s)-1)

/*
 *  Error ID
 *	tipid:          10000 - 10099   // wave info | rec info
 *	general error:  10100 - 10199
 *	asr|lm|post..:  20100 - 29999   // 内核应用模块错误码
 *	rtmp:           40000 - 49999
 *	falsh:          50000 - 59999
 *	server:         60000 - 69999
 */

#define WTK_EVAL_NOT_INIT 1
#define WTK_EVAL_POST_FAILED 2
#define WTK_EVAL_REF_INVALID 5
#define WTK_EVAL_EBNF_INVALID 6

typedef enum wtk_info_id
{
	WTK_SUCCESS                     = 0,
	WTK_ERROR_FAIL                  = -1,
	WTK_ERROR_EXCEPTION             = -2,

	WTK_INFO_ERROR_REF              = 00001,/* 遗留编码 */

	/* wave info | rec info */
	WTK_INFO_EMPTY_WAV              = 10000,
	WTK_INFO_FA_FORCEOUT            = 10001,
	WTK_INFO_REC_FORCEOUT           = 10002,
	WTK_INFO_REC_FAILED             = 10003,
	WTK_INFO_VOLUME_LOW             = 10004,
	WTK_INFO_CLIP                   = 10005,
	WTK_INFO_SNR                    = 10006,
	WTK_INFO_NOT_ENGLISH            = 10007,
	WTK_INFO_TRUNC                  = 10008,
	WTK_INFO_SPECTRUM                  = 10009,

	/* General errors 10100(0x2774) */
	WTK_ERROR_GENERAL               = 10100,
	WTK_ERROR_OUT_OF_MEMORY         = 10101,/* 内存不足 */
	WTK_ERROR_NO_ENOUGH_BUFFER      = 10102,/* 申请的内存过小，不够用 */
	WTK_ERROR_INVALID_PARA          = 10103,/* 无效参数：格式不对或者缺乏必要内容 */
	WTK_ERROR_INVALID_PARA_VALUE    = 10104,/* 参数值类型不对 */
	WTK_ERROR_OPEN_FILE             = 10105,/* 打开文件出错 */
	WTK_ERROR_ALREADY_EXIST         = 10106,/* 已经存在 */
	WTK_ERROR_NO_LICENSE            = 10107,/* 没有许口证 */
	WTK_ERROR_ACCESS                = 10108,/* 不能接触 */
	WTK_ERROR_NOT_SUPPORT           = 10109,/* 不支持 */
	WTK_ERROR_NOT_FOUND             = 10110,/* 没有找到 */
	WTK_ERROR_NO_DATA               = 10111,/* 没有数据，数据为空 */
	WTK_ERROR_INVALID_CONFIG        = 10112,/* 无效配置文件 */
	WTK_ERROR_CONFIG_INITIALIZE     = 10113,/* 配置初始化失败 */
	WTK_ERROR_NOT_INIT              = 10114,/* 没有初始化 */
	WTK_ERROR_REF_INVALID           = 10115,/* 无效的参考文本 */

	/* rec */
	WTK_ERROR_REC_RENERAL           = 20100,
	WTK_ERROR_REC_EBNF              = 20101,/* 单一语法错误 */
	WTK_ERROR_REC_NET               = 20102,/* 解码网络错误 */

	/* lm */
	WTK_ERROR_LM_GENERAL            = 20200,
	WTK_ERROR_LM_TEXT_EMPTY			= 20201,/* 输入原始训练文本为空 */
	WTK_ERROR_LM_TRIAN				= 20202,/* 训练语言模型失败 */
	WTK_ERROR_LM_MERGE				= 20203,/* 插值语言模型失败 */
	WTK_ERROR_LM_PRUNE				= 20204,/* 裁剪语言模型失败 */
	WTK_ERROR_LM_LATTICE			= 20205,/* 语言模型转lattice失败 */
	WTK_ERROR_LM_TXT_PARSER			= 20206,/* 处理文本失败 */
	WTK_ERROR_LM_HPARSE				= 20207,/* Hparse grammar失败 */
	WTK_ERROR_LM_NOT_SUPPORT_QT		= 20208,/* 不支持的题型参数 */
	WTK_ERROR_LM_FST		        = 20209,/* f训练fst网络失败 */

	/* post */
	WTK_ERROR_POST_GENERAL          = 20300,

	/* VAD */
	WTK_ERROR_VAD_GENERAL           = 20400,

}wtk_info_id_t;


struct wtk_errno
{
	int no;
	wtk_strbuf_t *buf;
};

wtk_errno_t* wtk_errno_new();
int wtk_errno_delete(wtk_errno_t *e);
void wtk_errno_reset(wtk_errno_t *e);
void wtk_errno_set(wtk_errno_t *e,int no,char *msg,int msg_bytes);
/**
 * parameter must end with NULL like wtk_errno_set_err(e,-1,"foo",NULL);
 */
void wtk_errno_set_string(wtk_errno_t *e,int no,...);
void wtk_errno_print(wtk_errno_t *e);
#ifdef __cplusplus
};
#endif
#endif
